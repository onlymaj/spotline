# Import smtplib for the actual sending function
import smtplib

# Import the email modules we'll need
from email.mime.text import MIMEText


def sendMail(FROM,TO,SUBJ,CONT,SERVER):
    msg = CONT

    # Send the message via our own SMTP server, but don't include the
    # envelope header.
    try:
        s = smtplib.SMTP(SERVER)
        s.sendmail(FROM, [TO], msg.as_string())
        print "Sending mail to "+TO+  ' For ' + SUBJ + ' Successfuly sent !'
    except Exception,e:
        print "Sending mail to "+TO+  ' For ' + SUBJ + ' Failed . ',e
    else:
        s.quit()
    
    
#
#   User Configuration
#


# Database Connection Info
SERVER     = 'localhost'
USERNAME   = 'root'
PASSWORD   = 'root'
DATABASE   = ''



# Email SMTP configuration
FROM   = 'onlymaj@python.com'
MSERVER = 'localhost'







